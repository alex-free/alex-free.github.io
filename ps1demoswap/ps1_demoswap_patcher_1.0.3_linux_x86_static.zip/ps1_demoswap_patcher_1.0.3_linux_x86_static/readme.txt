[alex-free.github.io](https://alex-free.github.io)
==================================================

[MottZilla](http://www.psxdev.net/forum/memberlist.php?mode=viewprofile&u=867)
and [Alex
Free](http://www.psxdev.net/forum/memberlist.php?mode=viewprofile&u=6018)
proudly present:

PS1 DemoSwap Patcher : Perfect CD-R Backup Loading On All Retail PSX Consoles + Japanese PSX Softmod
====================================================================================================

This tool offers 2 different patches that can be applied to a rip of a
PSX game to make it first boot a special
[Tonyhax](https://github.com/socram8888/tonyhax) loader. With this
special Tonyhax you get working CD audio and correct TOC data on all
consoles, even Japanese ones. This means PS1 DemoSwap Patcher provides
**the first methods ever enabling all stock unmodified SCPH-1000 and
SCPH-3000 consoles to play backups with correct CD audio**. On USA/PAL
consoles you even gain the ability to swap to the next (burned backup)
disc in games that span multiple discs without having to do another swap
trick for games like Parasite Eve.

If you do not want to patch a game with the special Tonyhax but still
want all the abilities it provides, you can use one of the FreePSXBoot
memory card files available for all BIOS versions included in every PS1
DemoSwap Patcher release since version 1.0.2. Find out more in the
[FreePSXBoot Memory Card Images](#freepsxboot) section.

Posts About PS1 DemoSwap Patcher At [psxdev.net](http://psxdev.net/forum)
-------------------------------------------------------------------------

-   [TOCPerfect](http://www.psxdev.net/forum/viewtopic.php?f=66&t=3881)
-   [MCTOOL](http://www.psxdev.net/forum/viewtopic.php?f=66&t=3910)

Links
-----

[Homepage](https://alex-free.github.io/ps1demoswap) \| [GitHub (Tonyhax
loader source)](https://github.com/alex-free/tonyhax)

Table Of Contents
-----------------

-   [Downloads](#downloads)
-   [About The TOCPerfect Patch](#tocperfect)
-   [TOCPerfect Requirements](#tocperfectrequirements)
-   [TOCPerfect Instructions](#tocperfectinstructions)
-   [About The DemoSwap Patch](#demoswap)
-   [DemoSwap Requirements](#demoswaprequirements)
-   [Demoswap Instructions](#demoswapinstructions)
-   [Adding Support For More Demo Discs](#moredemosupport)
-   [FreePSXBoot Memory Card Images](#freepsxboot)
-   [Important Info About Burning PSX Backups](#burning)
-   [Credits](#credits)

[]{#downloads}

Downloads
---------

### Version 1.0.3 (6/1/2022)

-   [Windows
    x86](https://alex-free.github.io/ps1demoswap/ps1_demoswap_patcher_1.0.3_win_x86.zip)
-   [Mac OS
    X](https://alex-free.github.io/ps1demoswap/ps1_demoswap_patcher_1.0.3_mac_os_x.zip)
    *For PowerPC, 32-bit Intel, and 64-bit Intel Macs running Mac OS X
    10.3.9 and up.*
-   [Linux
    x86](https://alex-free.github.io/ps1demoswap/ps1_demoswap_patcher_1.0.3_linux_x86_static.zip)
    *For modern 32-bit Linux distros (static build).*
-   [Linux
    x86\_64](https://alex-free.github.io/ps1demoswap/ps1_demoswap_patcher_1.0.3_linux_x86_64_static.zip)
    *For modern 64-bit Linux distros (static build).*

New in version 1.0.3:

-   Fixed Japanese VC3 console laser calibration, now works correctly on
    consoles such as SCPH-7500.
-   When using the DemoSwap Patch or a FreePSXBoot memory card, blocking
    the lid sensor is automatically detected with no user input
    required.
-   All japanese consoles now work the same way in the Tonyhax loader.
    CDDA audio/multi track games are automatically detected on
    SCPH-1000/SCPH-3000 in the new SetSession fix.

### Version 1.0.2 (5/26/2022)

-   [Windows
    x86](https://alex-free.github.io/ps1demoswap/ps1_demoswap_patcher_1.0.2_win_x86.zip)
-   [Mac OS
    X](https://alex-free.github.io/ps1demoswap/ps1_demoswap_patcher_1.0.2_mac_os_x.zip)
    *For PowerPC, 32-bit Intel, and 64-bit Intel Macs running Mac OS X
    10.3.9 and up.*
-   [Linux
    x86](https://alex-free.github.io/ps1demoswap/ps1_demoswap_patcher_1.0.2_linux_x86_static.zip)
    *For modern 32-bit Linux distros (static build).*
-   [Linux
    x86\_64](https://alex-free.github.io/ps1demoswap/ps1_demoswap_patcher_1.0.2_linux_x86_64_static.zip)
    *For modern 64-bit Linux distros (static build).*

### Version 1.0.1 (3/14/2022)

-   [Windows
    x86](https://alex-free.github.io/ps1demoswap/ps1_demoswap_patcher_1.0.1_win_x86.zip)
-   [Mac OS
    X](https://alex-free.github.io/ps1demoswap/ps1_demoswap_patcher_1.0.1_mac_os_x.zip)
    *For PowerPC, 32-bit Intel, and 64-bit Intel Macs running Mac OS X
    10.3.9 and up.*
-   [Linux
    x86](https://alex-free.github.io/ps1demoswap/ps1_demoswap_patcher_1.0.1_linux_x86_static.zip)
    *For modern 32-bit Linux distros (static build).*
-   [Linux
    x86\_64](https://alex-free.github.io/ps1demoswap/ps1_demoswap_patcher_1.0.1_linux_x86_64_static.zip)
    *For modern 64-bit Linux distros (static build).*

### Version 1.0 (2/28/2022)

-   [Windows
    x86](https://alex-free.github.io/ps1demoswap/PS1_DemoSwap_v1.0.zip)

[]{#tocperfect}

About The TOCPerfect Patch
--------------------------

Enables you to patch any psx game rip to first boot a special Tonyhax
which automatically re-read the TOC data to get working CD audio before
booting into the main game. If the console is USA/PAL the drive is also
unlocked before booting into the main game, so you have the ability to
switch from i.e. game disc 1 to a backup of game disc 2 mid-game.

TOCPerfect patching enables you to use **any backup loading method**
supported by your console and you will always get working CD audio (and
unlocked drive for USA/PAL consoles) regardless of the abilities of what
that backup loading method normally allows. For example, you can use any
of the below methods to boot a TOCPerfect patched CD-R:

-   Audio menu swap trick, and all other swap tricks mentioned in the
    original [swap trick
    guide](https://gamefaqs.gamespot.com/ps/916392-playstation/faqs/4708)
-   UNIROM
-   DemoSwap
-   Modchip (tonyhax provides stealth patches for non-stealth modchips)
-   PSX Change Boot Disc
-   PSN00bROM

[]{#tocperfectrequirements}

TOCPerfect Requirements
-----------------------

-   ANY PSX console
-   Any real PSX game disc that is for your console\'s region (if you
    want to do a swap trick to boot your TOCPerfect patched CD-R)
-   A high quality blank CD-R
-   A Backup of a ripped PSX game **with at least one audio track** that
    you want to play
-   A CD burner that can burn at a slow speed (4x recommended)

[]{#tocperfectinstructions}

TOCPerfect Instructions
-----------------------

TOCPerfect patch the first data track of the game you want to use. The
first data track will be named something like \"track 01.bin\" in your
game rip directory.

On Windows a basic GUI is supported. You can use the CLI on Windows as
well, but the GUI may be easier for many users.

### Windows (GUI)

-   You can drag and drop the \"track 01.bin\" file of the game you want
    to TOCPerfect patch into the \"PS1 DemoSwap Patcher.exe\" executable
    file. If you do not do this, you will be prompted to select the
    \'track 01.bin\' file in a file picker.
-   Select \"NO\" in the message box to select the TOCPerfect patch
    mode.
-   Select \"YES\" for Stealth mode if you do not want anything to
    display before booting the game. Select \"NO\" if you want to see
    debug output before the game boots.
-   Wait for PS1 DemoSwap Patcher to complete.

### Windows (CLI)

-   Start cmd.exe.

-   Select the type of TOCPerfect Patch you want to do with the second
    argument (-t or -ts).

    TOCPerfect Stealth patch (no debug output before game boots)
    example:

    `"PS1 DemoSwap Patcher.exe" -ts "track 01.bin"`

    Regular TOCPerfect patch (shows debug output before booting the
    game) example:

    `"PS1 DemoSwap Patcher.exe" -t "track 01.bin"`

-   Wait for PS1 DemoSwap Patcher to complete.

### Linux/Mac (CLI)

-   Start Terminal.

-   Select the type of TOCPerfect Patch you want to do with the second
    argument (-t or -ts).

    TOCPerfect Stealth patch (no debug output before game boots)
    example:

    `./ps1demoswap -ts "track 01.bin"`

    Regular TOCPerfect patch (shows debug output before booting the
    game) example:

    `./ps1demoswap -t "track 01.bin"`

-   Wait for PS1 DemoSwap Patcher to complete.

Burn the \".cue\" file in your game rip directory to a blank CD-R after
applying the TOCPerfect patch. Do a swap trick on your PSX console (If
you have a console with a serial number lower then 592xxx then you can
use the audio menu swap trick, which does not involve swapping a moving
disc) to boot your burned CD-R on your PSX console. The game will then
load with correct audio on all retail consoles, and an unlocked drive on
USA/PAL consoles.

### Ways To Boot A TOCPerfect Patched Backup CD-R

Audio Menu Swap Trick (works on PSX consoles with a serial number lower
then 592xxx):

-   Turn on the PS1 console with no game in it. Start the CD player,
    then place a real psx game in the psx console.
-   Press the lid sensor down with something that will keep it pressed
    down. You could use a molded gum wrapper. The lid sensor is at the
    top right of console, it is the circle button that is pressed down
    by the top of the CD drive lid). The real psx game will spin for a
    few seconds and then stop spinning.
-   Swap the real authentic PS1 game for a burned CD-R and exit the CD
    player. The burned CD-R will start spinning and boot.

Other options for consoles with a serial number of 592xxx or higher:

-   There are other swap tricks mentioned in the original [swap trick
    guide](https://gamefaqs.gamespot.com/ps/916392-playstation/faqs/4708)
    that support consoles with a serial number higher then 592xxx, but
    they require swapping a moving disc.
-   UNIROM
-   DemoSwap
-   Modchip (tonyhax provides stealth patches for non-stealth modchips)
-   PSX Change Boot Disc
-   PSN00bROM

**The early Japanese PSX consoles (SCPH-1000/SCPH-3000) take MUCH longer
to boot TOCPerfect patched backup CD-Rs in comparison to all other PSX
consoles. This is due to a bug in these CDROM BIOS firmwares that the
special Tonyhax has to work around. The more audio tracks in a backup
CD-R, the longer it will take for the game to boot. You can expect this
step to take possibly multiple minutes to complete. The console or
program is not stuck, please be patient while booting completes**.

[]{#demoswap}

About The DemoSwap Patch
------------------------

Enables you to patch a rip of one of the commonly found psx game demo
discs supported by PS1 DemoSwap Patcher that you own an authentic copy
of to boot a special Tonyhax when doing a simple disc swap from the
original authentic PSX game demo disc to the patched backup CD-R of the
same PSX game demo disc. This special simple disc swap trick does not
require any tricky timing, and best of all works on all PSX consoles.

If you have a USA/PAL console, you can then use MottZilla\'s
[MCTOOL](https://alex-free.github.io/ps1demoswap/MCTOOL_v103_beta_220501.zip)
to install TonyHax onto a memory card using the FreePSXBoot exploit for
future convience.

[]{#demoswaprequirements}

DemoSwap Requirements
---------------------

-   ANY PS1 Console.
-   A [real supported PSX game demo disc](#perdisc) (must match your
    console region).
-   2 high quality blank CD-Rs (one for the patched PSX game demo disc,
    one **any** backup CD-R that you actually want to play.
-   Rip of a supported PSX game demo disc.
-   CD burner that can burn at a slow speed (4x recommended).

[]{#demoswapinstructions}

DemoSwap Patch Instructions
---------------------------

Check the DiscLib.txt for the title of the demo disc you have or will
obtain. As of this writing all Interactive CD Sampler volumes 1 through
11 are supported. More demos can be added, details below.

Create a raw ISO image of your demo disc using a tool like ISOBuster.

On Windows a basic GUI is supported. You can use the CLI on Windows as
well, but the GUI may be easier for many users.

### Windows (GUI)

-   You can drag and drop the \"track 01.bin\" file of the demo disc rip
    you want to DemoSwap patch into the \"PS1 DemoSwap Patcher.exe\"
    executable file. If you do not do this, you will be prompted to
    select the \'track 01.bin\' file in a file picker.
-   Select \"Yes\" in the message box to select the DemoSwap patch mode.
-   Wait for PS1 DemoSwap Patcher to complete.

### Windows (CLI)

-   Start cmd.exe.

-   Execute \"PS1 DemoSwap Patcher.exe\" with the -d argument. Example:

    `"PS1 DemoSwap Patcher.exe" -d "track 01.bin"`

-   Wait for PS1 DemoSwap Patcher to complete.

### Linux/Mac (CLI)

-   Start Terminal.

-   Execute \"PS1 DemoSwap Patcher.exe\" with the -d argument. Example:

    `./ps1demoswap -d "track 01.bin"`

-   Wait for PS1 DemoSwap Patcher to complete.

-   Burn the \".cue\" file in your PSX game demo disc rip directory to a
    blank CD-R after applying the DemoSwap patch.

-   Put the original demo disc in your PS1. Using your method of choice
    you must hold down the lid switch so the console will read discs
    with the lid open. A wooden toothpick, a stretched out pen spring,
    and molded aluminum foil are a few things that can work.

-   Power on your PSX console and consult the \"Per Disc Instructions\"
    section immedietly below.

[]{#perdisc}

Per Disc Instructions

All Discs Note - When you remove the original disc you do not need to
rush to replace it with the CD-R. I found on my SCPH-7501 when removing
the disc the motor and laser will try to read the disc you have removed
for a few seconds before giving up. After that you can easily place the
CD-R into the console. When you take your next action the CD-R should
begin spinning and reading. However if you removed the disc at a time
when data was being read the system may lock up. Read the notes below to
know when you should be removing the original disc and swapping in the
CD-R.

Vol 1 - Select \"Loaded\" demo. While on the screen with Start and Help,
swap discs, then start the demo.

Vol 2 - Load Demo \"Need For Speed\". On \"game mode\" menu swap discs.
Press Select to exit to main menu. Load NBA Shoot Out demo.

Vol 3 & 3.5 - Load Crash Bandicoot demo. When you control Crash, swap
discs. Then Press Select to return to main menu. Load 2Xtreme demo.

Vol 4 - Start Croc demo. Once controlling Croc swap discs. Press Select
to exit. Start Parappa demo.

Vol 5 - Start Crash 2 demo. Once you control Crash, swap discs. Press
select to return to menu. Start Parappa demo.

Vol 6 - Start Crash 2 demo. Once you control Crash, swap discs. Press
select to return to menu. Start Bloody Roar.

Vol 7 - Select Blasto demo. On instruction screen swap discs, then start
demo.

Vol 8 - Select Spyro demo. On instruction screen swap discs, then start
demo.

Vol 9 - Select Crash 3 demo. On instruction screen swap discs, then
start demo.

Vol 10 - Select Contender demo. On instruction screen swap discs, then
start demo.

Vol 11 - Select Ape Escape demo. On instruction screen swap discs, then
start demo.

PSOne Wherever, Whenever, Forever - Select Atlantis demo. On instruction
screen swap discs, then start demo.

After you complete the Per Disc Instructions for your PSX game demo
disc, a special Tonyhax will load. This Tonyhax behaves differently on
Early Japanes Consoles, Later Japanese Consoles, and USA/PAL consoles.

Once Tonyhax is loaded via the DemoSwap method, the patched PSX game
demo disc backup CD-R will stop.

### Japanese Console Instructions

Once the special Tonyhax boots, the following message will be displayed
after the the patched PSX game demo disc backup CD-R stops spinning:

    Put in a backup/import disc, then press X

Once you press X, on most Japanese consoles you will see the following
message:

    Sending SetSession

If you instead see:

    Sending SetSession fix
    Please wait, this may take a few minutes

You have a very early Japanese PSX console (SCPH-1000/3000). **These
early Japanese PSX consoles take MUCH longer to boot backups with CD
Audio in comparison to all other PSX consoles. This is due to a bug in
these CDROM BIOS firmwares that the special Tonyhax has to work around.
The more audio tracks in a backup CD-R, the longer it will take for the
game to boot. You can expect this step to take possibly multiple minutes
to complete. The console or program is not stuck, please be patient
while booting completes as this waiting is unavoidable.**

Finally, you will breifly see the message `Starting`. The screen will go
black, and then your backup CD-R will boot with perfect CD audio!

### USA/PAL Console Instructions

On these consoles, unblock the lid sensor when you see the message:

`Swap CD now`

Remove the patched PSX game demo disc backup CD-R. Put in the backup
CD-R you want to play, and close the console lid like normal. A breif
`Starting` message will appear. The screen will go black, and then your
backup CD-R will boot with perfect CD audio! You also have the ability
to open and close the lid as normal, as well as swap to another burned
backup CD-R (i.e. swap to the next (burned backup) disc in games that
span multiple discs without having to do another swap trick for games
like Parasite Eve).

[]{#moredemosupport}

Adding Support For More Demo Discs
----------------------------------

You can add your own demo disc to DiscLib.txt if your demo is not
supported. The format of DiscLib is simple. The first line is a Title of
the disc. Recommended you use the name in the Redump set. The second
line is the Executable file loaded by SYSTEM.CNF. This is needed to
identify each disc. The third line is the name of the demo executable to
replace with TonyHax. I usually choose the first demo selected on the
disc but you can choose any you wish. The DiscLib.txt should end with
three lines of three dots. So add your discs before the \... or just add
your discs at the top of the file.

Make an ISO image of your demo disc that is not supported (the only
requirement for the unsupported Demo Disc is that it has at least one
audio track). Open the SYSTEM.CNF file and find the boot executable.
Then find the demo executable you want to replace. Add this information
to DiscLib.txt. ISOBuster can help you find all of this information.

When to swap the discs depends on the menu of the disc. Some demos have
menus that stream data off the disc for full motion video and swapping
the discs could result in a freeze or crash if you don\"t swap fast
enough. My instructions above for the 11 volumes of Interactive CD
Sampler avoid these issues. The swap methods given allow for relaxed
timing. Using Vol 5 as an example, while the Crash demo is running and
you can control the character you should be able to carefully grab the
disc by the edge and center stopping it. Remove it in a short peroid of
time so you don\"t hurt the motor. After you remove it you should be
able to wait for the motor to stop trying to spin and then put your CD-R
in. Then you can press Select to exit the demo which will cause the CD
to spin up again and load the main menu. Then you can start the demo
that was replaced with TonyHax.

[]{#freepsxboot}

FreePSXBoot Memory Card Images
------------------------------

Memory card files are included in PS1 DemoSwap v1.0.2 and above for all
BIOS versions that boot into the special Tonyhax loader, using the
[FreePSXBoot](https://github.com/brad-lin/FreePSXBoot) exploit. These
memory card files must be restored to a PSX memory card (official Sony
memory cards highly recommended). One such way to do this is to use
[Memory Card Annihilator
v2.0](https://www.ps2-home.com/forum/viewtopic.php?t=116) with a modded
PS2 console and USB flash drive containing the memory card file. Here
are the steps below:

Copy the correct memory card file for your PSX console\'s BIOS version
from the \"memory\_card\_files\" directory found in the PS1 DemoSwap
Patcher release to a FAT32 formatted USB flash drive that your PS2
console can read.

Console models and the BIOS versions they contain are listed below:

-   SCPH-1000 (rev a/early rev b) - BIOS-1.0-1994-09-22-I
-   SCPH-1000 (rev b) - BIOS-1.1-1995-01-22-I
-   SCPH-1001 (rev a) - BIOS-2.0-1995-05-07-A
-   SCPH-1001 (rev b) - BIOS-2.1-1995-07-17-A
-   SCPH-1001 (rev c) - BIOS-2.2-1995-12-04-A
-   SCPH-1002 (rev a) - BIOS-2.0-1995-05-10-E
-   SCPH-1002 (rev b) - BIOS-2.1-1995-07-17-E
-   SCPH-1002 (rev c) - BIOS-2.2-1995-12-04-E
-   SCPH-3000 - BIOS-1.1-1995-01-22-I
-   SCPH-3500 - BIOS-2.1-1995-07-17-I
-   SCPH-5000 - BIOS-2.2-1995-12-04-I
-   SCPH-5001 - BIOS-3.0-1996-11-18-A
-   SCPH-5003 - BIOS-2.2-1995-12-04-A
-   SCPH-5500 - BIOS-3.0-1996-09-09-I
-   SCPH-5501 - BIOS-3.0-1996-11-18-A
-   SCPH-5502 - BIOS-3.0-1997-01-06-E
-   SCPH-5503 - BIOS-3.0-1996-11-18-A
-   SCPH-5552 - BIOS-3.0-1997-01-06-E
-   SCPH-5903 - BIOS-2.2-1995-12-04-A
-   SCPH-7000 - BIOS-4.0-1997-08-18-I
-   SCPH-7000W - BIOS-4.1-1997-11-14-I
-   SCPH-7001 - BIOS-4.1-1997-12-16-A
-   SCPH-7002 - BIOS-4.1-1997-12-16-E
-   SCPH-7003 - BIOS-3.0-1996-11-18-A
-   SCPH-7500 - BIOS-4.0-1997-08-18-I
-   SCPH-7501 - BIOS-4.1-1997-12-16-A
-   SCPH-7502 - BIOS-4.1-1997-12-16-E
-   SCPH-7503 - BIOS-4.1-1997-12-16-A
-   SCPH-9000 - BIOS-4.0-1997-08-18-I
-   SCPH-9001 - BIOS-4.1-1997-12-16-A
-   SCPH-9002 - BIOS-4.1-1997-12-16-E
-   SCPH-9003 - BIOS-4.1-1997-12-16-A
-   SCPH-9903 - BIOS-4.1-1997-12-16-A
-   SCPH-100 - BIOS-4.3-2000-03-11-I
-   SCPH-101 (rev a) - BIOS-4.4-2000-03-24-A
-   SCPH-101 (rev b) - BIOS-4.5-2000-05-25-A
-   SCPH-102 (rev a) - BIOS-4.4-2000-03-24-E
-   SCPH-102 (rev b) - BIOS-4.5-2000-05-25-E
-   SCPH-103 - BIOS-4.5-2000-05-25-A

If you have a PSX console that can have multiple different BIOS
versions, you may have to try each different memory card file one by one
until you figure out what BIOS version you need for your PSX console.

After the correct memory card file is copied to the USB flash drive that
your PS2 can read:

-   Download the [Memory Card Annihilator
    v2.0](https://www.ps2-home.com/forum/viewtopic.php?t=116) and
    extract it\'s .elf file.
-   Copy the Memory Card Annihilator v2 .elf file to a FAT32 formatted
    USB flash drive that your PS2 console can read.
-   Insert the PSX memory card and USB flash drive with the PS2 console
    off. Boot your modded PS2 (FreeHDBoot or FreeMCBoot, or something
    like that is required) and start the uLaunchElf program.
-   Navigate to the \"mass\" device and launch the Memory Card
    Annihilator v2 .elf file you previosly copied to the USB flash
    drive.
-   Select your PS1 memory card in the menu and then select restore. In
    the file picker navigate to the memory card file you copied to the
    USB flash drive previously.
-   Wait for the restore to complete and press X. Remove your memory
    card and put it into **Slot 2** of your PSX console.

Now you can power on your PSX console **without a disc** and select the
memory card option in the boot menu. After a few seconds, a special
Tonyhax will load. This Tonyhax behaves differently on Early Japanes
Consoles, Later Japanese Consoles, and USA/PAL consoles.

**Note: If you are using a Japanese console, at least one real NTSC-J
PSX game disc is required. No real PSX game disc is required for USA/PAL
consoles.**

### Japanese Console Instructions

Once the special Tonyhax boots, the following message will be displayed:

    Put in a real NTSC-J PSX game disc, then block the lid sensor

If you instead see the following messages:

    Remove the exploited memory card
    Put in a real NTSC-J PSX game disc, then block the lid sensor

You have a very early Japanese console (VC0) that requires you to remove
the exploited memory card before continuing to boot the game. If you do
not do this, the game will most likely not boot and or the Tonyhax
loader may freeze when begining to load the game.

After you block the lid sensor, your game will spin up and then stop.
Next, you will see this message:

    Put in a backup/import disc, then press X

Once you press X, on most Japanese consoles you will see the following
message:

    Sending SetSession

If you instead see:

    Sending SetSession fix
    Please wait, this may take a few minutes

You have a very early Japanese PSX console (SCPH-1000/3000/VC0/VC1(a)).
**These early Japanese PSX consoles take MUCH longer to boot backups
with CD Audio in comparison to all other PSX consoles. This is due to a
bug in these CDROM BIOS firmwares that the special Tonyhax has to work
around. The more audio tracks in a backup CD-R, the longer it will take
for the game to boot. You can expect this step to take possibly multiple
minutes to complete. The console or program is not stuck, please be
patient while booting completes as this waiting is unavoidable.**

Finally, you will breifly see the message `Starting`. The screen will go
black, and then your backup CD-R will boot with perfect CD audio!

### USA/PAL Console Instructions

On these consoles, put in the backup CD-R you want to play and close the
PSX console\'s lid when you see this message:

`Swap CD now`

A breif `Starting` message will appear. The screen will go black, and
then your backup CD-R will boot with perfect CD audio! You also have the
ability to open and close the lid as normal, as well as swap to another
burned backup CD-R (i.e. swap to the next (burned backup) disc in games
that span multiple discs without having to do another swap trick for
games like Parasite Eve).

[]{#burning}

Important Info About Burning PSX Backups
----------------------------------------

Your **burner** and **CD-R media** matter! The PSX likes 74min/650MB
CD-Rs more then 80min/700MB CD-Rs. The PSX also likes very-reflective
CD-R media (with a dark bottom). The slower you can burn, the better.

New old stock VerbatimDataLifePlus 74min/650MB CD-Rs from the turn of
the century are the best I have used so far. I burn them at 4x speed
using a Cen Dyne 32x12x40 IDE CD-RW burner with an IDE to USB adapter.

Recommended burning programs:

-   [IMGBurn](https://www.imgburn.com) (Windows).
-   [CDRDAO](http://cdrdao.sourceforge.net) (Mac OS
    X/Linux/\*BSD/Windows).

If you use cdrdao, you must use the `--swap` argument for discs with
CDDA audio. Example:

    cdrdao write --speed 1 --swap --eject yourgame.cue

[]{#credits}

Credits
-------

### PS1 DemoSwap Patcher

-   The TOCPerfect concept was first released as [TOCPerfect
    v1.0](https://alex-free.github.io/tocperfect) by Alex Free.
-   MottZilla is the original sole creator of PS1 DemoSwap Patcher v1.0.
    MottZilla reimplemented the TOCPerfect concept into a much superior
    method, and included his implementation alongside of his DemoSwap
    idea in PS1 DemoSwap Patcher.
-   Alex Free ported PS1 DemoSwap Patcher to Mac OS X and Linux.
-   Alex Free discovered that SetSession is bugged on the VC0 and VC1(a)
    CDROM BIOS firmwares, and came up with a bypass idea by mashing
    SetSession in frustration on MottZilla\'s PSX CDROM Debugger program
    that was created to debug the SetSession command on a early
    SCPH-1001 and SCPH-1000 with BIOS v1.0.
-   Martin Korth confirmed that SetSession is bugged on VC0 and VC1(a)
    CDROM BIOS firmware. He also wrote the amazing [No cash PSX
    Specs](https://problemkaputt.de/psx-spx.htm) Alex Free and MottZilla
    used to find out about various commands needed to make a loader.
-   MottZilla wrote controller input support for TonyHAX and all the
    functions that add support for Japanese VC0/VC1(a) consoles with the
    bugged SetSession to Alex Free\'s requests.
-   MottZilla came up with reset+unlock without opening/closing the lid
    method for TOCPerfect booting on USA/PAL consoles.
-   MottZilla came up with the CDROM BIOS Firmware detection and VC3
    console laser recalibration to fix disc reading after using
    SetSession to get the TOC data on VC3 consoles.
-   Alex Free put everything together and tested the modifed Tonyhax
    loader that targets DemoSwap, TOCPerfect, and FreePSXBoot booting
    methods for all retail consoles.

### TonyHAX Acknowledgements

[Socram8888](https://github.com/socram8888) is the original developer of
the Tonyhax loader, which is the base that the heavily modifed special
Tonyhax loader used by PS1 DemoSwap Patcher and the FreePSXBoot memory
card files. The original Tonyhax loader credits are below, in
alphabetical order:

-   Alex Free for adding the boot CD image.
-   ChampionLeake for documenting the Brunswick exploits at PlayStation
    dev wiki.
-   Gerardo Rodriguez for suggesting Cool Boarders 4 on a YouTube
    comment.
-   \@FMecha for suggesting Castrol Honda VTR on Twitter.
-   John Wilbert Villamor (aka Lameguy64) for creating mkpsxiso.
-   Jose Silva for adding support for Sports Superbike II and XS Moto.
-   Martin Korth for his super awesome technical documentation page that
    was vital for the development of this project, as well as for
    developing the no\$psx emulator that was also essential for
    debugging.
-   Patrick Vogt for testing on multiple development PS1 consoles.
-   Everyone that\'s reported the issues on GitHub and helped Socram8888
    make it better.
