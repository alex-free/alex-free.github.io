PS1 DemoSwap Patcher
By: MottZilla

[ Summary ]
This program will patch various common Demo Discs to make it easy to run TonyHax to boot Import or
CD-R discs. It will replace one of the demo executables with TonyHax and by doing a simple disc swap
you can load TonyHax. You must have an original demo disc that is supported. It is recommended after
starting TonyHax to run MCTOOL to install FreePSXBoot + TonyHax onto a memory card.

[ Why ]
I created this program and MCTOOL to give someone without access to commonly used tools a way to
install TonyHax and FreePSXBoot. No modded PS2 required. No PC memory card interface required. 
The swap trick on most consoles can be very difficult for people to perform successfuly. And mistakes
could damage the console. With the 'Demo Swap' method you can use a common demo disc and a patched CD-R 
of the same demo disc to run an Import or CD-R disc. No tricky timing or fast reflexes required.

[ Requirements ]
PS1 Console (NTSC/U or PAL)
Supported Demo Disc (must match your console region)


[ Instructions ]
1. Check the DiscLib.txt for the title of the demo disc you have or will obtain. As of this writing all
   Interactive CD Sampler volumes 1 through 11 are supported. More demos can be added, details below.
2. Create a raw ISO image of your demo disc using a tool like ISOBuster.
3. Run PS1 DemoSwap Patcher, choose DemoSwap patching mode. Select your demo disc ISO.
4. The program will report if patching succeeded or not.
5. Burn the patched disc to a CD-R. You can ignore any ECC/EDC, L-EC, etc. errors reported during
   disc verification. Error correction fields are auto corrected by your burner.
6. Put the original demo disc in your PS1. Using your method of choice you must hold down the lid
   switch so the console will read discs with the lid open. A wooden toothpick can work.
7. Power on the system and consult the 'Per Disc Instruction' section.

[ TOCPerfect ]
This program can also patch games using CDDA audio tracks to load TonyHax prior to loading the game
to enable the system to have a correct TOC and play game audio correctly. The idea was first worked
on by Alex-Free ( https://alex-free.github.io/tocperfect/ )

[ Per Disc Instruction ]
* All Discs Note - When you remove the original disc you do not need to rush to replace it with the CD-R.
  I found on my SCPH-7501 when removing the disc the motor and laser will try to read the disc you have
  removed for a few seconds before giving up. After that you can easily place the CD-R into the console.
  When you take your next action the CD-R should begin spinning and reading. However if you removed the
  disc at a time when data was being read the system may lock up. Read the notes below to know when you
  should be removing the original disc and swapping in the CD-R.

* Vol 1 - Select 'Loaded' demo. While on the screen with Start and Help, swap discs, then start the demo.

* Vol 2 - Load Demo 'Need For Speed'. On 'game mode' menu swap discs. Press Select to exit to main menu.
  Load NBA Shoot Out demo.

* Vol 3 & 3.5 - Load Crash Bandicoot demo. When you control Crash, swap discs. Then Press Select to
  return to main menu. Load 2Xtreme demo.

* Vol 4 - Start Croc demo. Once controlling Croc swap discs. Press Select to exit. Start Parappa demo.

* Vol 5 - Start Crash 2 demo. Once you control Crash, swap discs. Press select to return to menu. Start Parappa demo.
* Vol 6 - Start Crash 2 demo. Once you control Crash, swap discs. Press select to return to menu. Start Bloody Roar.
* Vol 7 - Select Blasto demo. On instruction screen swap discs, then start demo.
* Vol 8 - Select Spyro demo. On instruction screen swap discs, then start demo.
* Vol 9 - Select Crash 3 demo. On instruction screen swap discs, then start demo.
* Vol 10 - Select Contender demo. On instruction screen swap discs, then start demo.
* Vol 11 - Select Ape Escape demo. On instruction screen swap discs, then start demo.
* PSOne Wherever, Whenever, Forever - Select Atlantis demo. On instruction screen swap discs, then start demo.

[ Adding more Demo Discs ]
You can add your own demo disc to DiscLib.txt if your demo is not supported. The format of DiscLib is simple.
The first line is a Title of the disc. Recommended you use the name in the Redump set. The second line is
the Executable file loaded by SYSTEM.CNF. This is needed to identify each disc. The third line is the name
of the demo executable to replace with TonyHax. I usually choose the first demo selected on the disc but you
can choose any you wish. The DiscLib.txt should end with three lines of three dots. So add your discs before
the ... or just add your discs at the top of the file. 

Make an ISO image of your demo disc that is not supported. Open the SYSTEM.CNF file and find the boot exectuable.
Then find the demo executable you want to replace. Add this information to DiscLib.txt. ISOBuster can help you
find all of this information. 

When to swap the discs depends on the menu of the disc. Some demos have menus that stream data off the disc
for full motion video and swapping the discs could result in a freeze or crash if you don't swap fast enough.
My instructions above for the 11 volumes of Interactive CD Sampler avoid these issues. The swap methods given
allow for relaxed timing. Using Vol 5 as an example, while the Crash demo is running and you can control the
character you should be able to carefully grab the disc by the edge and center stopping it. Remove it in a
short peroid of time so you don't hurt the motor. After you remove it you should be able to wait for the
motor to stop trying to spin and then put your CD-R in. Then you can press Select to exit the demo which
will cause the CD to spin up again and load the main menu. Then you can start the demo that was replaced
with TonyHax.