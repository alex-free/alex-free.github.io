# PSX 80 Minute Patcher

Brought To You By Alex Free & MottZilla. Heavily based on [MottZilla's](mottzilla) [PS1 DemoSwap Patcher](https://alex-free.github.io/ps1demoswap).

The earliest PS2 console models (SCPH-10000-SCPH-3904) have an [issue](https://github.com/socram8888/tonyhax/issues/24) reading the last file on a burned 80 minute CD-R PSX backup, which can be a really big issue if that last file is the `SYSTEM.CNF` or PS-EXE file.

This patcher adds a 6 minute long 'dummy' file (full of 0s) as the last file in the first data track of a PSX game (named PSX80MP). This allows the affected PS2 console models to gracefully recover from what before was a [fatal seek error](#theory) that prevented many games from being played by these PS2 consoles (hard-mod or soft-mod).

This patcher may also help the affected PS2 consoles to read PSX games burned to 80 minute CD-Rs better in general since games will eventually seek to the last file on disc at some point during game play. The most dramatic difference though is when the game won't boot without being ran through this patcher.

Only early PS2 consoles before the SCPH-50000 series (SCPH-10000-SCPH-39004) appear to be affected by this bug, and require the patcher for 80 minute CD-R media.

An alternative to using the patcher is to use [High Quality 74 minute 650MB CD-Rs](https://github.com/socram8888/tonyhax/issues/24#issuecomment-1364089965), such as the Verbatim DataLifePlus CD-Rs from the 90s (with copyright date 1997 or 1999 on the back of the CD case). The [affected games](#boot-test-list) will work without being PSX80MP patched when burned to such media.

This patcher is for 80 minute (even low-quality) 700MB CD-Rs to allow them to work like the high quality 74 minute 650MB CD-Rs that are no longer made brand new. Patched CD images can be burned with [standard CD burning software](#standard-cd-burning-software).

## Downloads

### Version 1.0.2 (6/29/2023)

*	[psx80mp-1.0.2-windows\_x86](https://alex-free.github.io/psx80mp/psx80mp-1.0.2-windows_x86.zip) _For Windows 95 OSR 2.5 Or Newer (32-bit Windows)_
*	[psx80mp-1.0.2-windows\_x86\_64](https://alex-free.github.io/psx80mp/psx80mp-1.0.2-windows_x86_64.zip) _For 64-bit Windows_
*	[psx80mp-1.0.2-linux\_x86](https://alex-free.github.io/psx80mp/psx80mp-1.0.2-linux_x86_static.zip) _For x86 Linux Distros_
*	[psx80mp-1.0.2-linux\_x86\_64](https://alex-free.github.io/psx80mp/psx80mp-1.0.2-linux_x86_64_static.zip) _For x86\_64 Linux Distros_

## Usage

Make sure you have a BIN+CUE image of the game you want to patch. If it has CD audio tracks, it must be in multi-bin format **(seperate bin files)**. This is the format that all '[redump](http://redump.org)' images are in. The patcher can not work correctly with multi-bin games that have been 'merged' into one track, with a tool such as [binmerge](https://github.com/putnam/binmerge).

Once you have the CD image, there are 2 ways you can interact with the PSX80MP patcher:

### Drag n' Drop

On Windows and most Linux distributions, you can simply drag the track 01 bin file ontop of the `psx80mp.exe` or `psexe80mp` executable file found in the downloaded release.

### Tradditional CLI

On Linux, execute `./psx80mp <track 01 bin file>` in your Terminal. On Windows, execute  `psx80mp.exe <track 01 bin file>` in `cmd.exe`. _Replace `<track 01 bin file >` with the actual first and or only data track from the game you want to patch_.

![Resident Evil USA Directors Cut Patched 1](images/resident-evil-directors-cut-usa-patched-1.png)

![Resident Evil USA Directors Cut Patched 2](images/resident-evil-directors-cut-usa-patched-2.png)

![Resident Evil 2 USA Disc 1 Patched 1](images/resident-evil-2-disc-1-usa-patched-1.png)

![Resident Evil 2 USA Disc 2 Patched 1](images/resident-evil-2-disc-1-usa-patched-2.png)

### Games Containing Additional Anti-Piracy Measures

Some later PSX games are containing one of the following additional anti-piracy measures:

*   [APv1](https://alex-free.github.io/aprip/#apv1)
*   [APv2](https://alex-free.github.io/aprip/#apv2)
*   [LibCrypt v1](https://alex-free.github.io/aprip/#libcrypt-v1)
*   [LibCrypt v2](https://alex-free.github.io/aprip/#libcrypt-v2)
*   [LibCrypt v3](https://alex-free.github.io/aprip/#libcrypt-v3)
*   [LibCrypt v4](https://alex-free.github.io/aprip/#libcrypt-v4)
*   [EDC](https://alex-free.github.io/aprip/#edc)

If your game has APv1, APv2, LibCrypt v1, or LibCrypt v2 you can use the [APrip patcher](https://alex-free.github.io/aprip) in addition to the PSX80MP patcher to get the game to work as expected.

APrip does not yet support patching games containing LibCrypt v3, LibCrypt v4, or EDC protection however.

## Standard CD Burning Software

PSX80MP patched disc images can be burned by _any CD burning software that regenerates EDC protection on the fly_. If you don't know what this is, you probably have it already. Such popular software includes:

*   [ImgBurn](https://www.imgburn.com/).
*   [CDRDAO](https://cdrdao.sourceforge.net/) (with the default `generic-mmc` driver. This can also be explicitly set with the `--driver generic-mmc` argument to `cdrdao`).


## Theory

* The PSX console was released in Japan on December 4th 1994. At this time CD-R technology was in it's [infancy](https://en.wikipedia.org/wiki/CD-R). It was designed for (most likely [72 minute](http://problemkaputt.de/psx-spx.htm#cdromresponsetimings)) pressed CD-ROMs.

*  Sony warned developers in early 1995 to not use anything longer then 71 minute CD-Rs on the official [SCEA BBS](https://psx.arthus.net/sdk/Psy-Q/DOCS/BBS/scea_bbs.pdf):

3/27/95 7:56 PM
*How to make Debug Station CD BillÊ"Angus" Guschwan
CD
To make debug station cds:
1) Get rid of PCread, pollhost, etal 2) Link with 2mbyte.obj 3) Do a cpe2x on the .cpe file 4a) Add files to the CDGEN. 4b) Choose correct file type for XA stuff. Use Mode 2 Form 1 for game data. Use Mode 2 Form 2 for XA files. Use the File Type button to set it for each file. Standard file is Mode 2 Form 1. 5) In Additional Information button dialog of Volume panel of CDGEN, set System Area File to the path of your company's license.dat file. For example, c:\cdgen\licensej.dat 6) In Master button dialog of Layout panel of CDGEN, set License Area to J if you have a Japanese debug station. If you have an American one, set it to A. If it is European, set it to E. 7a) Set the minutes to 74 minutes. You should use 71 minute media. 74 minute might work but we don't support it. Use it at your own risk. 7b) Hit RECÉ button. Double speed record should work OK. 8) Always Verify after you bake a disc. It is that easy. Angus
PS: We need to get you the license.dat file. I know. Bug your Account Executive for it. PSPS: Note you will not see the license.dat file on final discs because it is stored in the system area

*   80-minute CD-R discs [marginally violate](https://en.wikipedia.org/wiki/CD-R) the Red Book physical format specifications, and longer discs are noncompliant.

*   The CDROM BIOS seems to split seek distance somehow into coarse steps (eg. minutes) and fine steps (eg. seconds/sectors), so 1-minute seek distance may have completely different timings than 59-seconds distance.
The amount of data per spiral winding increases towards ends of the disc (so the drive head will need to be moved by shorter distance when moving from minute 59 to 60 as than moving from 00 to 01).
The CDROM BIOS contains some seek distance table, which is probably optimized for 72-minute discs (or whatever capacity is used on original PSX discs). [80-minute CDRs may have tighter spiral windings](http://problemkaputt.de/psx-spx.htm#cdromresponsetimings) (the above seek table is probably causing the drive head to be moved too far on such discs, which will raise the seek time as the head needs to be moved backwards to compensate that error).

The earliest PS2 console models (SCPH-10000-SCPH-390004) have a different CD/DVD drive and iOP then all later fat and slim models that came after (SCPH-50000+). For some reason, a seek that fails to read the last file on a burned 80 minute CD-R (the outermost part of the disc) results in an unrecoverable error that leaves the drive unresponsive. The strangest thing is that all PSX consoles appear to not have the same behavior, and can read/seek the last file on a burned 80 minute CD-R, and seemingly recover from the 'seek table distance mis-match' while the early PS2 models mentioned can not. This seems to be a regression in the CDROM BIOS for PSX compatibility mode.

My guess is that the PS2 goes to read the last file on disc, misses it (goes to far out on the disc) since it expects much looser spiral windings of data then what are on 80 minute CD-R media, and then it encounters 'unwritten' data on the CD-R which it doesn't know what to do with. It then becomes unrespsosive.

The PSX80MP patcher works because when it overshoots what was before the last file on the CD-R, it will still be in the range of real data (6 minutes of 0 bytes are the last possible data on the disc).

## Boot Test List

These games have been verified by myself to not boot at all (due to `SYSTEM.CNF` or PS-EXE read error) **without** being PSX80MP patched first on my SCPH-10000 Japanese launch PS2 (using [Tonyhax International](https://github.com/alex-free/tonyhax)).

### Kurushi / I.Q: Intelligent Qube

Versions: [Europe](http://redump.org/disc/26776/), [Japan](http://redump.org/disc/2267/), [Japan Demo](http://redump.org/disc/68874/), [USA](http://redump.org/disc/7932/), [USA Demo](http://redump.org/disc/57665/)

### MediEvil

_Note:_ this game uses LibCrypt v1 protection. Please use the [APrip patcher](https://alex-free.github.io/aprip/#for-libcrypt-v1libcrypt-v2) in addition to the PSX80MP patcher to bypass the LibCrypt v1 protection.

Versions: [Japan](http://redump.org/disc/33095/), [USA](http://redump.org/disc/3472/), [Europe](http://redump.org/disc/592/), [France](http://redump.org/disc/13389/), [Germany](http://redump.org/disc/25542/), [Italy](http://redump.org/disc/29475/), [Spain](http://redump.org/disc/1584/).

### Resident Evil Director's Cut

Versions: [USA](http://redump.org/disc/123/), [Europe](http://redump.org/disc/3382/), [France](http://redump.org/disc/5825/), [Germany](http://redump.org/disc/15507/).

## Resident Evil 2 / BioHazard 2

Versions: Japan ([Disc 1](http://redump.org/disc/1525/), [Disc 2](http://redump.org/disc/1526/)), USA ([Disc 1](http://redump.org/disc/340/), [Disc 2](http://redump.org/disc/341/)), Europe ([Disc 1](http://redump.org/disc/621/), [Disc 2](http://redump.org/disc/1195/)), France ([Disc 1](http://redump.org/disc/10259/), [Disc 2](http://redump.org/disc/10260/)), Germany ([Disc 1](http://redump.org/disc/509/), [Disc 2](http://redump.org/disc/464/)), Italy ([Disc 1](http://redump.org/disc/2743/), [Disc 2](http://redump.org/disc/2742/)), Spain ([Disc 1](http://redump.org/disc/5217/), [Disc 2](http://redump.org/disc/5218/)).

## MegaMan X4 / RockMan X4

Versions: [Japan](http://redump.org/disc/4777/), [Japan Demo](http://redump.org/disc/36649/), [Japan Special Box](http://redump.org/disc/33903/), [USA](http://redump.org/disc/7075/), [Europe](http://redump.org/disc/14657/).
