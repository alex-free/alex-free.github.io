# [Miria Must Live - A Fallout 2 Mod](reamde.md) -> Changelog

## v1.0 (1/31/2026)

* [mira-must-live-fo2-mod-v1.0](https://github.com/alex-free/alex-free.github.io/raw/refs/heads/master/miria-must-live-fo2-mod/mira-must-live-fo2-mod-v1.0.zip)